package com.example.michael.designpattrenproject.Classes.Iterator;

/**
 * Created by almog on 23/02/2018.
 */

public interface Container {
    public Iterator getIterator();
}
